package com.mycompany.myapp;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.mycompany.myapp.R;  // ✅ R import edildi

import java.io.IOException;
import java.net.InetAddress;
import java.util.HashSet;

public class MainActivity extends Activity {

    private static final String TAG = "IPTarayici";
    private TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);  // activity_main.xml dosyasını yükle

        textView = findViewById(R.id.textView);
        Button startButton = findViewById(R.id.startButton);

        startButton.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.ACCESS_FINE_LOCATION)
                        != PackageManager.PERMISSION_GRANTED) {
						ActivityCompat.requestPermissions(MainActivity.this,
														  new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);
					} else {
						agiTara();
					}
				}
			});
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        if (requestCode == 1 &&
			grantResults.length > 0 &&
			grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            agiTara();
        } else {
            Toast.makeText(this, "Konum izni gerekli!", Toast.LENGTH_LONG).show();
        }
    }

    private void agiTara() {
        new Thread(new Runnable() {
				@Override
				public void run() {
					WifiManager wifiManager = (WifiManager) getSystemService(WIFI_SERVICE);
					WifiInfo wifiInfo = wifiManager.getConnectionInfo();
					int ip = wifiInfo.getIpAddress();

					String ipBase = String.format("%d.%d.%d.",
												  (ip & 0xff),
												  (ip >> 8 & 0xff),
												  (ip >> 16 & 0xff));

					final HashSet<String> bulunanIPler = new HashSet<>();
					final HashSet<String> conflictIPs = new HashSet<>();

					for (int i = 1; i <= 254; i++) {
						final String host = ipBase + i;

						try {
							InetAddress inetAddress = InetAddress.getByName(host);
							if (inetAddress.isReachable(300)) {
								runOnUiThread(new Runnable() {
										@Override
										public void run() {
											textView.append("Cihaz bulundu: " + host + "\n");
										}
									});

								if (bulunanIPler.contains(host)) {
									conflictIPs.add(host);
								} else {
									bulunanIPler.add(host);
								}
							}
						} catch (IOException e) {
							Log.e(TAG, "Hata: " + e.getMessage());
						}
					}

					runOnUiThread(new Runnable() {
							@Override
							public void run() {
								if (!conflictIPs.isEmpty()) {
									textView.append("\nÇakışan IP'ler:\n");
									for (String conflictIP : conflictIPs) {
										textView.append("⚠️ Çakışan IP: " + conflictIP + "\n");
									}
								} else {
									textView.append("\nÇakışan IP yok.\n");
								}
							}
						});
				}
			}).start();
    }
}
